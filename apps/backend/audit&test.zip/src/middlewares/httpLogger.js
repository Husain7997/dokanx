const pinoHttp = require("pino-http");
const logger = require("../infrastructure/logger/logger");

module.exports = pinoHttp({
  logger,
  customProps: (req) => ({
    requestId: req.requestId,
  }),
});