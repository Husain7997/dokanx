const router = require('express').Router();
const ctrl = require('../../controllers/admin/adjustment.controller');
const { protect, allowRoles } = require('../../middlewares');

router.use(protect);
router.use(allowRoles('ADMIN'));

router.post('/refund', ctrl.refundShop);
router.post('/adjust', ctrl.adjustWallet);

module.exports = router;