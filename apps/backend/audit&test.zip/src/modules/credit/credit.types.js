module.exports = {
  OPERATIONS: {
    ISSUE_CREDIT: "ISSUE_CREDIT",
    RECEIVE_PAYMENT: "RECEIVE_PAYMENT",
  },
};