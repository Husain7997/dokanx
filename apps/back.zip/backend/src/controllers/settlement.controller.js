const Wallet = require("../models/wallet.model");
const Ledger = require("../models/ledger.model");
const mongoose = require("mongoose");


const { processShopSettlement } = require('../services/settlement.service');
const { payoutToShop } = require('../services/wallet.service');

exports.createSettlement = async (req, res) => {
  try {
    const result = await processShopSettlement(req.params.shopId);
    if (!result) return res.json({ message: 'No pending orders' });
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.payoutSettlement = async (req, res) => {
  try {
    const result = await payoutToShop(req.params.settlementId, req.body.bankDetails);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};


