const express = require("express");
const cors = require("cors");
const session = require("express-session");

const passport = require("./modules/auth/googleAuth");

const authRoutes = require("./modules/auth/auth.routes");

const shopRoutes = require("./routes/shop.routes");
const productRoutes = require("./routes/product.routes");
const orderRoutes = require("./routes/order.routes");
const adminRoutes = require("./routes/admin.routes");
const paymentRoutes = require("./routes/payment.routes");
const settlementRoutes = require("./routes/settlement.routes");
const errorHandler = require("./utils/errorHandler");

const app = express();

app.use(cors());
app.use(express.json());

app.use("/api/payments/webhook",
  express.raw({ type: "application/json" })
);

app.use(session({ secret: "some_secret", resave: false, saveUninitialized: false }));
app.use(passport.initialize());
app.use(passport.session());

// Routes
app.use("/api/auth", authRoutes);
app.use("/api/shops", shopRoutes);
app.use("/api/products", productRoutes);
app.use("/api/orders", orderRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/payments", paymentRoutes);
app.use("/api/settlements", settlementRoutes);

app.get("/api/health", (req, res) => {
  res.json({ status: "OK" });
});
app.get(
  "/api/auth/google",
  passport.authenticate("google", { scope: ["profile", "email"] })
);

app.get(
  "/api/auth/google/callback",
  passport.authenticate("google", { failureRedirect: "/" }),
  (req, res) => {
    // Successful login
    res.redirect("/"); // later redirect to frontend dashboard
  }
);
app.use(errorHandler);

module.exports = app;



