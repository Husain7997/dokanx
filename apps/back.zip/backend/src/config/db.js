// src/config/db.js
const mongoose = require("mongoose");

const connectDB = async (uri) => {
  if (mongoose.connection.readyState === 1) {
    return;
  }

  await mongoose.connect(uri);
  console.log("✅ MongoDB Connected");
};

module.exports = connectDB;
