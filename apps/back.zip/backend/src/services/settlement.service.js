const Settlement = require('../models/Settlement');
const ShopWallet = require('../models/ShopWallet');
const Order = require('../models/order.model');
const mongoose = require('mongoose');

async function processShopSettlement(shopId) {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const orders = await Order.find({ shop: shopId, paymentStatus: 'SUCCESS', settled: false });

    if (!orders.length) {
      await session.endSession();
      return null;
    }

    const totalAmount = orders.reduce((sum, o) => sum + o.amount, 0);

    const settlement = await Settlement.create([{
      shop: shopId,
      orders: orders.map(o => o._id),
      totalAmount,
      status: 'PROCESSING'
    }], { session });

    const wallet = await ShopWallet.findOneAndUpdate(
      { shop: shopId },
      { $inc: { balance: totalAmount }, $push: { transactions: { type: 'CREDIT', amount: totalAmount, reference: settlement[0]._id, status: 'SUCCESS' } } },
      { new: true, upsert: true, session }
    );

    await Order.updateMany({ _id: { $in: orders.map(o => o._id) } }, { settled: true }, { session });

    await session.commitTransaction();
    session.endSession();

    return { settlementId: settlement[0]._id, walletBalance: wallet.balance };

  } catch (err) {
    await session.abortTransaction();
    session.endSession();
    throw err;
  }
}

module.exports = { processShopSettlement };
