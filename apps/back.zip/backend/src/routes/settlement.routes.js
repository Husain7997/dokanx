const express = require('express');
const router = express.Router();
const settlementController = require('../controllers/settlement.controller');

router.post('/:shopId', settlementController.createSettlement);
router.post('/payout/:settlementId', settlementController.payoutSettlement);

module.exports = router;
