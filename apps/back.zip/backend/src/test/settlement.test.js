const request = require("supertest");
const mongoose = require("mongoose");
const app = require("../app");
const connectDB = require("../config/db");

beforeAll(async () => {
  await connectDB(process.env.MONGO_URI_TEST);
});

afterAll(async () => {
  await mongoose.connection.close();
});

describe("Multi-tenant Settlement & Wallet Payout", () => {

  it("✅ Settlement creates correctly and wallet credited", async () => {
    const res = await request(app)
      .post("/api/settlements")
      .send({
        shopId: new mongoose.Types.ObjectId(),
        amount: 500
      });

    expect(res.statusCode).toBe(201);
  });

});



const ShopWallet = require('../models/ShopWallet');
const Settlement = require('../models/Settlement');
const Order = require('../models/order.model');

// Mock axios for payout API
jest.mock('axios');
const axios = require('axios');

describe('Multi-tenant Settlement & Wallet Payout', () => {
  let shopId;
  let settlementId;

  beforeAll(async () => {
    // MongoDB connect
    await mongoose.connect(process.env.MONGO_URI_TEST)
    // Create dummy shopId
    shopId = new mongoose.Types.ObjectId();

    // Create sample orders
    await Order.create([
      { shop: shopId, amount: 1000, paymentStatus: 'SUCCESS', settled: false },
      { shop: shopId, amount: 500, paymentStatus: 'SUCCESS', settled: false },
    ]);
  });

  afterAll(async () => {
    await Order.deleteMany({ shop: shopId });
    await ShopWallet.deleteMany({ shop: shopId });
    await Settlement.deleteMany({ shop: shopId });
    await mongoose.connection.close();
  });

  test('✅ Settlement creates correctly and wallet credited', async () => {
    const res = await request(app).post(`/api/settlements/${shopId}`);
    expect(res.statusCode).toBe(200);
    expect(res.body.settlementId).toBeDefined();
    expect(res.body.walletBalance).toBe(1500); // 1000+500

    settlementId = res.body.settlementId;

    const wallet = await ShopWallet.findOne({ shop: shopId });
    expect(wallet.balance).toBe(1500);
    expect(wallet.transactions.length).toBe(1);
    expect(wallet.transactions[0].type).toBe('CREDIT');
  });

  test('✅ Payout succeeds and wallet updated', async () => {
    // Mock bank API success
    axios.post.mockResolvedValue({ data: { status: 'SUCCESS', payoutId: 'PAYOUT123' } });

    const res = await request(app)
      .post(`/api/settlements/payout/${settlementId}`)
      .send({ bankDetails: { accountNumber: '1234567890' } });

    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.payoutId).toBe('PAYOUT123');

    const wallet = await ShopWallet.findOne({ shop: shopId });
    expect(wallet.balance).toBe(0);
    expect(wallet.transactions.find(t => t.type === 'DEBIT')).toBeDefined();

    const settlement = await Settlement.findById(settlementId);
    expect(settlement.status).toBe('COMPLETED');
    expect(settlement.payoutId).toBe('PAYOUT123');
  });

  test('❌ Payout fails on insufficient balance', async () => {
    // Create new settlement exceeding wallet
    const newSettlement = await Settlement.create({ shop: shopId, orders: [], totalAmount: 100, status: 'PROCESSING' });

    const res = await request(app)
      .post(`/api/settlements/payout/${newSettlement._id}`)
      .send({ bankDetails: { accountNumber: '1234567890' } });

    expect(res.statusCode).toBe(500);
    expect(res.body.error).toMatch(/Insufficient wallet balance/);

    const settlement = await Settlement.findById(newSettlement._id);
    expect(settlement.status).toBe('PROCESSING'); // Should not change
  });

  test('❌ Payout fails when bank API fails', async () => {
    // Credit wallet first
    await ShopWallet.create({ shop: shopId, balance: 200, transactions: [] });
    const newSettlement = await Settlement.create({ shop: shopId, orders: [], totalAmount: 200, status: 'PROCESSING' });

    axios.post.mockRejectedValue(new Error('Bank API down'));

    const res = await request(app)
      .post(`/api/settlements/payout/${newSettlement._id}`)
      .send({ bankDetails: { accountNumber: '1234567890' } });

    expect(res.statusCode).toBe(500);
    expect(res.body.error).toMatch(/Bank API down/);

    const settlement = await Settlement.findById(newSettlement._id);
    expect(settlement.status).toBe('FAILED');
  });

});
