const Order = require("../models/order.model");
const Product = require("../models/product.model");
const { createAudit } = require("../utils/audit.util");
const crypto = require("crypto");

const {
  reserveStock,
  releaseStock,
  deductStock,
} = require("../services/Inventory.service");

/**
 * ORDER STATUS TRANSITION RULES
 */
function canTransition(from, to) {
  const rules = {
    PLACED: ["CONFIRMED", "CANCELLED"],
    CONFIRMED: ["DELIVERED", "CANCELLED"],
    CANCELLED: [],
    DELIVERED: [],
  };

  return rules[from]?.includes(to);
}

/**
 * PLACE ORDER
 */
exports.placeOrder = async (req, res) => {
  try {
    const shop = req.shop;
    const user = req.user || null;
    const { items, email, phone } = req.body;

    if (!items || items.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Order items required",
      });
    }

    if (!user && !phone && !email) {
      return res.status(400).json({
        success: false,
        message: "Guest orders require phone or email",
      });
    }

    if (user && user.isBlocked) {
      return res.status(403).json({ message: "User blocked" });
    }

    if (!shop.isActive) {
      return res.status(403).json({ message: "Shop suspended" });
    }

    const isGuest = !user;
    const guestId = isGuest ? crypto.randomUUID() : null;

    let orderItems = [];
    let totalAmount = 0;

    for (const item of items) {
      const product = await Product.findOne({
        _id: item.product,
        shop: shop._id,
      });

      if (!product) {
        return res.status(404).json({
          success: false,
          message: "Product not found",
        });
      }

      orderItems.push({
        product: product._id,
        quantity: item.quantity,
        price: product.price,
      });

      totalAmount += product.price * item.quantity;
    }

    const order = new Order({
      shop: shop._id,
      user: user ? user._id : null,
      guestId,
      items: orderItems,
      totalAmount,
      status: "PLACED",
    });

    await order.save();

    await createAudit({
      action: "ORDER_CREATED",
      performedBy: user ? user._id : null,
      targetType: "Order",
      targetId: order._id,
      meta: {
        guest: isGuest,
        email,
        phone,
      },
      req,
    });

    res.status(201).json({
      success: true,
      guest: isGuest,
      data: order,
    });
  } catch (error) {
    console.error("ORDER ERROR:", error);
    res.status(500).json({
      success: false,
      message: "Order failed",
    });
  }
};

/**
 * GET SHOP ORDERS (OWNER / ADMIN)
 */
exports.getOrders = async (req, res) => {
  try {
    const orders = await Order.find({ shop: req.shop._id })
      .populate("items.product", "name price")
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      data: orders,
    });
  } catch (error) {
    console.error("GET ORDERS ERROR:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch orders",
    });
  }
};

/**
 * GET ALL ORDERS (ADMIN)
 */
exports.getAllOrders = async (req, res) => {
  try {
    const page = Number(req.query.page) || 0;
    const limit = Number(req.query.limit) || 10;

    const orders = await Order.find()
      .skip(page * limit)
      .limit(limit)
      .populate("user shop");

    const total = await Order.countDocuments();

    res.json({
      success: true,
      page,
      limit,
      total,
      data: orders,
    });
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch all orders" });
  }
};

/**
 * UPDATE ORDER STATUS
 */exports.updateOrderStatus = async (req, res) => {
  try {
    const order = req.order; // from middleware
    const { status } = req.body;

    const previousStatus = order.status;

    // 🔁 VALID TRANSITIONS
    const rules = {
      PLACED: ["CANCELLED"],
      CONFIRMED: ["DELIVERED", "CANCELLED"],
      DELIVERED: [],
      CANCELLED: [],
    };

    if (!rules[previousStatus]?.includes(status)) {
      return res.status(400).json({
        message: `Invalid transition from ${previousStatus} to ${status}`,
      });
    }

    order.status = status;
    await order.save();

    // 🔗 Inventory Hook
    if (previousStatus !== status) {
      if (status === "CONFIRMED") {
        for (const item of order.items) {
          await reserveStock({
            shopId: order.shop,
            productId: item.product,
            quantity: item.quantity,
            orderId: order._id,
          });
        }
      }

      if (status === "CANCELLED") {
        for (const item of order.items) {
          await releaseStock({
            shopId: order.shop,
            productId: item.product,
            quantity: item.quantity,
            orderId: order._id,
          });
        }
      }

      if (status === "DELIVERED") {
        for (const item of order.items) {
          await deductStock({
            shopId: order.shop,
            productId: item.product,
            quantity: item.quantity,
            orderId: order._id,
          });
        }
      }
    }

    res.json({ message: "Order updated", order });
  } catch (err) {
    console.error("ORDER STATUS ERROR:", err.message);
    res.status(500).json({ message: "Failed to update order" });
  }
};
