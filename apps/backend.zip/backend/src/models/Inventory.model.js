const mongoose = require("mongoose");

const inventorySchema = new mongoose.Schema(
  {
    shop: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Shop",
      required: true,
      index: true,
    },

    product: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Product",
      required: true,
      index: true,
    },

    stock: {
      type: Number,
      required: true,
      min: 0,
      default: 0,
    },

    reserved: {
      type: Number,
      required: true,
      min: 0,
      default: 0,
    },

    lowStockAlert: {
      type: Number,
      default: 5,
    },
  },
  { timestamps: true }
);

// 🚫 Prevent duplicate inventory per product per shop
inventorySchema.index({ shop: 1, product: 1 }, { unique: true });


module.exports = mongoose.model("Inventory", inventorySchema);
