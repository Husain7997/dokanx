const Inventory = require("../models/Inventory.model");
const InventoryTransaction = require("../models/inventoryTransaction.model");

/**
 * Reserve stock when order is CONFIRMED
 */
async function reserveStock({ shopId, productId, quantity, orderId }) {
  const inventory = await Inventory.findOne({ shop: shopId, product: productId });

  if (!inventory) throw new Error("Inventory not found");

  if (inventory.stock - inventory.reserved < quantity) {
    throw new Error("Insufficient stock");
  }
console.log('RESERVE STOCK CALLED', orderId);
  inventory.reserved += quantity;
  await inventory.save();

  await InventoryTransaction.create({
    shop: shopId,
    product: productId,
    type: "RESERVE",
    quantity,
    order: orderId,
  });

  return inventory;
}

/**
 * Release reserved stock (order cancelled / expired)
 */
async function releaseStock({ shopId, productId, quantity, orderId }) {
  const inventory = await Inventory.findOne({ shop: shopId, product: productId });

  if (!inventory) throw new Error("Inventory not found");

  inventory.reserved = Math.max(0, inventory.reserved - quantity);
  await inventory.save();

  await InventoryTransaction.create({
    shop: shopId,
    product: productId,
    type: "RELEASE",
    quantity,
    order: orderId,
  });

  return inventory;
}

/**
 * Deduct final stock (order DELIVERED)
 */
async function deductStock({ shopId, productId, quantity, orderId }) {
  const inventory = await Inventory.findOne({ shop: shopId, product: productId });

  if (!inventory) throw new Error("Inventory not found");

  inventory.stock -= quantity;
  inventory.reserved = Math.max(0, inventory.reserved - quantity);

  if (inventory.stock < 0) {
    throw new Error("Stock went negative – data corruption");
  }

  await inventory.save();

  await InventoryTransaction.create({
    shop: shopId,
    product: productId,
    type: "DEDUCT",
    quantity,
    order: orderId,
  });

  return inventory;
}

module.exports = {
  reserveStock,
  releaseStock,
  deductStock,
};
