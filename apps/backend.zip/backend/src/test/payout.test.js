const { createShopWallet, processPayout } = require("./helpers/testHelpers");

describe("Payout Gateway", () => {
  it("should trigger payout", async () => {
    const wallet = await createShopWallet({ balance: 1000 });
    const result = await processPayout(wallet._id);
    expect(result).toBeDefined();
    expect(result.status).toBe("SUCCESS");
  }, 30000);
});
