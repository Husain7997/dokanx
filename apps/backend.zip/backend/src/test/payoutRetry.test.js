const { createShopWallet, processPayout } = require("./helpers/testHelpers");

describe("Payout Retry", () => {
  it("should retry failed payout", async () => {
    const wallet = await createShopWallet({ balance: 1000 });
    const result = await processPayout(wallet._id);
    expect(result.status).toBe("SUCCESS");
  }, 30000);
});
