// src/test/setup.js
const mongoose = require("mongoose");
const dotenv = require("dotenv");

// Load test env
dotenv.config({ path: ".env.test", override: true });

// Jest global timeout
jest.setTimeout(30000);

// MongoDB connection
beforeAll(async () => {
  if (!process.env.MONGO_URI_TEST) {
    throw new Error("MONGO_URI_TEST is missing in .env.test");
  }
  await mongoose.connect(process.env.MONGO_URI_TEST);
  console.log("✅ MongoDB connected (test)");
});

// Clean DB before each test
beforeEach(async () => {
  const collections = Object.keys(mongoose.connection.collections);
  for (const collName of collections) {
    await mongoose.connection.collections[collName].deleteMany({});
  }
});

// Disconnect DB after all tests
afterAll(async () => {
  if (mongoose.connection.readyState === 1) {
    await mongoose.connection.dropDatabase();
    await mongoose.connection.close();
    console.log("✅ MongoDB disconnected (test)");
  }
});

// Middleware mocks
jest.mock("../middlewares/auth.middleware", () => ({
  protect: (req, res, next) => {
    req.user = { _id: "testUserId", role: "admin" };
    next();
  },
  role: (roleName) => (req, res, next) => next(),
  auth: (req, res, next) => next(),
}));

jest.mock("../middlewares/shop.middleware", () => ({
  protect: (req, res, next) => next(),
  blockCustomer: (req, res, next) => next(),
}));

// Ledger enum helper
global.validLedgerValues = {
  type: ["CREDIT", "DEBIT"],
  source: ["SYSTEM", "USER"],
  referenceType: ["ORDER", "SETTLEMENT", "REFUND"],
};
