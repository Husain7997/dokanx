const mongoose = require("mongoose");

const User = require("../../models/user.model");
const Shop = require("../../models/shop.model");
const Wallet = require("../../models/wallet.model");
const Ledger = require("../../models/ledger.model");
const Settlement = require("../../models/Settlement");
const TaxRule = require("../../models/TaxRule");

// 🔹 Ensure mongoose connected
async function ensureConnected() {
  if (mongoose.connection.readyState !== 1) {
    await new Promise((resolve) => {
      mongoose.connection.once("connected", resolve);
    });
  }
}

// 🔹 Create user
async function createUser(overrides = {}) {
  await ensureConnected();

  return await User.create({
    email: overrides.email || `user-${Date.now()}@test.com`,
    password: "123456",
    role: overrides.role || "OWNER",
  });
}

// 🔹 Create shop
async function createShop(overrides = {}) {
  await ensureConnected();

  const owner = overrides.owner || (await createUser());

  return await Shop.create({
    name: overrides.name || "Test Shop " + Date.now(),
    domain: overrides.domain || `test-${Date.now()}.dokanx.com`,
    owner: owner._id,
  });
}

// 🔹 Create wallet
async function createShopWallet(overrides = {}) {
  await ensureConnected();

  const shop = overrides.shop || (await createShop());

  const wallet = await Wallet.create({
    shopId: shop._id,
    balance: overrides.balance || 0,
    currency: "BDT",
  });

  return {
    wallet,
    shopId: shop._id,
  };
}

// 🔹 Create ledger entry
async function createLedger(overrides = {}) {
  await ensureConnected();

  return await Ledger.create({
    shopId: overrides.shopId,
    amount: overrides.amount || 100,
    type: overrides.type || "CREDIT",
    source: overrides.source || "TEST",
    reference: overrides.reference || "REF-" + Date.now(),
  });
}

// 🔹 Create settlement
async function createSettlement(overrides = {}) {
  await ensureConnected();

  return await Settlement.create({
    shopId: overrides.shopId,
    grossAmount: overrides.grossAmount || 1000,
    fee: overrides.fee || 50,
    netAmount: overrides.netAmount || 950,
    status: "PENDING",
    idempotencyKey: overrides.idempotencyKey || "SET-" + Date.now(),
  });
}

// 🔹 Create tax rule (🔥 FIXED: type is REQUIRED)
async function createTaxRule(overrides = {}) {
  await ensureConnected();

  return await TaxRule.create({
    name: overrides.name || "VAT",
    type: overrides.type || "PERCENTAGE",   // 🔥 THIS FIX FIXES VALIDATION ERROR
    rate: overrides.rate || 15,
    active: true,
  });
}

module.exports = {
  createUser,
  createShop,
  createShopWallet,
  createLedger,
  createSettlement,
  createTaxRule,
};
