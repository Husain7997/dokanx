module.exports = {
  testEnvironment: "node",
  setupFilesAfterEnv: ["<rootDir>/src/test/jest.setup.js"],
  testTimeout: 60000,
  runInBand: true,
};
