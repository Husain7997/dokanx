const mongoose = require("mongoose");
const dotenv = require("dotenv");

beforeAll(async () => {
  // 🔥 Load test env
  dotenv.config({ path: __dirname + "/.env.test" });

  if (!process.env.MONGO_URI_TEST) {
    throw new Error("❌ MONGO_URI_TEST is missing in .env.test");
  }

  mongoose.set("bufferCommands", false);

  await mongoose.connect(process.env.MONGO_URI_TEST, {
    autoIndex: true,
  });
});

afterEach(async () => {
  // 🔥 Clean all collections after each test
  const collections = mongoose.connection.collections;
  for (const key in collections) {
    await collections[key].deleteMany({});
  }
});

afterAll(async () => {
  if (mongoose.connection.readyState === 1) {
    await mongoose.connection.close();
  }
});
