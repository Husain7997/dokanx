const Order = require("../models/order.model");
const ROLES = require("./role.middleware");

const canUpdateOrderStatus = async (req, res, next) => {
  const { orderId } = req.params;
  const { status } = req.body;

  const order = await Order.findById(orderId);
  if (!order) {
    return res.status(404).json({ message: "Order not found" });
  }

  req.order = order;

  if (!req.user || !req.user.role) {
    return res.status(401).json({ message: "Login required" });
  }

  const role = req.user.role;

  // 🟢 CUSTOMER
  if (role === ROLES.CUSTOMER) {
    if (status !== "CANCELLED") {
      return res.status(403).json({
        message: "Customer can only cancel order",
      });
    }

    if (!order.user || order.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not your order" });
    }

    if (order.status !== "PLACED") {
      return res.status(400).json({
        message: "Only PLACED order can be cancelled",
      });
    }

    return next();
  }

  // 🟢 SHOP OWNER
  if (role === ROLES.SHOP_OWNER) {
    if (!["DELIVERED", "CANCELLED"].includes(status)) {
      return res.status(403).json({
        message: "Owner can only DELIVER or CANCEL",
      });
    }
    return next();
  }

  // 🟢 ADMIN
  if (role === ROLES.SUPER_ADMIN) {
    return next();
  }

  return res.status(403).json({ message: "Unauthorized role" });
};

module.exports = {
  canUpdateOrderStatus,
};
